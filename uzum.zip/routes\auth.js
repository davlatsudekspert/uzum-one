const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database');
const { authMiddleware } = require('../middleware/auth');
const fs = require('fs');
const path = require('path');

const router = express.Router();

router.post('/register', (req, res) => {
  const { name, phone, password, role } = req.body;
  if (!name || !phone || !password || !role) {
    return res.status(400).json({ error: 'Barcha maydonlarni to\'ldiring' });
  }
  if (!['buyer', 'seller'].includes(role)) {
    return res.status(400).json({ error: 'Noto\'g\'ri rol' });
  }
  const existing = db.query('users').find(u => u.phone === phone);
  if (existing) {
    return res.status(409).json({ error: 'Bu raqam allaqachon ro\'yxatdan o\'tgan' });
  }
  const hash = bcrypt.hashSync(password, 10);
  const user = db.query('users').insert({
    name, phone, password: hash, role, avatar: null, createdAt: new Date().toISOString()
  });
  const token = jwt.sign({ id: user.id, role }, process.env.JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user: { id: user.id, name, phone, role, avatar: null } });
});

router.post('/login', (req, res) => {
  const { phone, password } = req.body;
  if (!phone || !password) {
    return res.status(400).json({ error: 'Telefon va parolni kiriting' });
  }
  const user = db.query('users').find(u => u.phone === phone);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Telefon yoki parol noto\'g\'ri' });
  }
  const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '30d' });
  res.json({
    token,
    user: { id: user.id, name: user.name, phone: user.phone, role: user.role, avatar: user.avatar }
  });
});

router.get('/me', authMiddleware, (req, res) => {
  const user = db.query('users').find(u => u.id === req.userId);
  if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
  res.json({ user: { id: user.id, name: user.name, phone: user.phone, role: user.role, avatar: user.avatar } });
});

router.post('/change-name', authMiddleware, (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'Ism kerak' });
  db.query('users').update(req.userId, { name });
  res.json({ success: true, name });
});

router.post('/change-password', authMiddleware, (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (!oldPassword || !newPassword) return res.status(400).json({ error: 'Parollarni kiriting' });
  const user = db.query('users').find(u => u.id === req.userId);
  if (!bcrypt.compareSync(oldPassword, user.password)) {
    return res.status(400).json({ error: 'Joriy parol noto\'g\'ri' });
  }
  const hash = bcrypt.hashSync(newPassword, 10);
  db.query('users').update(req.userId, { password: hash });
  res.json({ success: true });
});

router.post('/change-avatar', authMiddleware, (req, res) => {
  const { avatar } = req.body;
  if (!avatar) {
    return res.status(400).json({ error: 'Rasm yuklang' });
  }
  const matches = avatar.match(/^data:image\/(png|jpg|jpeg|gif|webp);base64,(.+)$/);
  if (!matches) {
    return res.status(400).json({ error: 'Noto\'g\'ri rasm formati' });
  }
  const ext = matches[1] === 'jpeg' ? 'jpg' : matches[1];
  const buffer = Buffer.from(matches[2], 'base64');
  const filename = `avatar_${req.userId}_${Date.now()}.${ext}`;
  const filepath = path.join(__dirname, '..', 'uploads', filename);
  fs.writeFileSync(filepath, buffer);
  const url = `/uploads/${filename}`;
  db.query('users').update(req.userId, { avatar: url });
  res.json({ success: true, avatar: url });
});

module.exports = router;
