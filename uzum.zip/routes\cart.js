const express = require('express');
const db = require('../database');
const { authMiddleware } = require('../middleware/auth');
const router = express.Router();

router.get('/', authMiddleware, (req, res) => {
  const cartItems = db.query('cartItems').filter(c => c.userId === req.userId);
  const products = db.query('products').all();

  const items = cartItems.map(ci => {
    const prod = products.find(p => p.id === ci.productId);
    if (!prod) return null;
    return {
      id: ci.id,
      quantity: ci.quantity,
      productId: prod.id,
      name: prod.name,
      price: prod.price,
      images: prod.images,
      category: prod.category,
      sellerId: prod.userId
    };
  }).filter(Boolean);

  items.sort((a, b) => b.id - a.id);
  res.json({ items });
});

router.post('/add', authMiddleware, (req, res) => {
  const { productId, quantity = 1 } = req.body;
  if (!productId) return res.status(400).json({ error: 'Product ID kerak' });

  const product = db.query('products').find(p => p.id === productId);
  if (!product) return res.status(404).json({ error: 'Mahsulot topilmadi' });

  const existing = db.query('cartItems').find(c => c.userId === req.userId && c.productId === productId);
  if (existing) {
    db.query('cartItems').update(existing.id, { quantity: existing.quantity + quantity });
  } else {
    db.query('cartItems').insert({
      userId: req.userId, productId, quantity
    });
  }
  res.json({ success: true });
});

router.post('/update', authMiddleware, (req, res) => {
  const { itemId, quantity } = req.body;
  if (!itemId || quantity < 1) return res.status(400).json({ error: 'Noto\'g\'ri ma\'lumot' });
  const item = db.query('cartItems').find(c => c.id === itemId && c.userId === req.userId);
  if (!item) return res.status(404).json({ error: 'Savatda topilmadi' });
  db.query('cartItems').update(itemId, { quantity });
  res.json({ success: true });
});

router.delete('/remove/:itemId', authMiddleware, (req, res) => {
  const itemId = parseInt(req.params.itemId);
  const item = db.query('cartItems').find(c => c.id === itemId && c.userId === req.userId);
  if (!item) return res.status(404).json({ error: 'Savatda topilmadi' });
  db.query('cartItems').delete(itemId);
  res.json({ success: true });
});

router.delete('/clear', authMiddleware, (req, res) => {
  db.query('cartItems').deleteWhere(c => c.userId === req.userId);
  res.json({ success: true });
});

module.exports = router;
