const express = require('express');
const db = require('../database');
const { authMiddleware } = require('../middleware/auth');
const router = express.Router();

router.get('/', authMiddleware, (req, res) => {
  const likes = db.query('likes').filter(l => l.userId === req.userId);
  const products = db.query('products').all();
  const users = db.query('users').all();

  const likedProducts = likes.map(l => {
    const p = products.find(pr => pr.id === l.productId);
    if (!p) return null;
    const seller = users.find(u => u.id === p.userId);
    return { ...p, sellerName: seller ? seller.name : '', liked: true };
  }).filter(Boolean);

  likedProducts.sort((a, b) => b.id - a.id);
  res.json({ products: likedProducts });
});

router.post('/toggle', authMiddleware, (req, res) => {
  const { productId } = req.body;
  if (!productId) return res.status(400).json({ error: 'Product ID kerak' });

  const existing = db.query('likes').find(l => l.userId === req.userId && l.productId === productId);
  if (existing) {
    db.query('likes').delete(existing.id);
    res.json({ liked: false });
  } else {
    db.query('likes').insert({ userId: req.userId, productId });
    res.json({ liked: true });
  }
});

module.exports = router;
