const express = require('express');
const db = require('../database');
const { authMiddleware } = require('../middleware/auth');
const router = express.Router();

router.get('/conversations', authMiddleware, (req, res) => {
  const messages = db.query('messages').all();
  const users = db.query('users').all();

  const myMessages = messages.filter(m => m.fromUserId === req.userId || m.toUserId === req.userId);
  const conversationIds = new Set();
  const conversations = [];

  for (const m of myMessages) {
    const otherId = m.fromUserId === req.userId ? m.toUserId : m.fromUserId;
    if (conversationIds.has(otherId)) continue;
    conversationIds.add(otherId);

    const otherUser = users.find(u => u.id === otherId);
    const lastMsg = myMessages.filter(x => (x.fromUserId === req.userId && x.toUserId === otherId) || (x.fromUserId === otherId && x.toUserId === req.userId));
    lastMsg.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    conversations.push({
      userId: otherId,
      name: otherUser ? otherUser.name : 'Unknown',
      avatar: otherUser ? otherUser.avatar : null,
      lastMessage: lastMsg[0] ? lastMsg[0].text : '',
      lastTime: lastMsg[0] ? lastMsg[0].createdAt : null,
      unread: lastMsg.filter(x => x.fromUserId === otherId && !x.read).length
    });
  }

  conversations.sort((a, b) => {
    if (!a.lastTime) return 1;
    if (!b.lastTime) return -1;
    return new Date(b.lastTime) - new Date(a.lastTime);
  });

  res.json({ conversations });
});

router.get('/:userId', authMiddleware, (req, res) => {
  const otherId = parseInt(req.params.userId);
  const messages = db.query('messages').all()
    .filter(m =>
      (m.fromUserId === req.userId && m.toUserId === otherId) ||
      (m.fromUserId === otherId && m.toUserId === req.userId)
    )
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));

  db.query('messages').all().forEach(m => {
    if (m.toUserId === req.userId && m.fromUserId === otherId && !m.read) {
      db.query('messages').update(m.id, { read: true });
    }
  });

  res.json({ messages });
});

router.post('/send', authMiddleware, (req, res) => {
  const { toUserId, text, productId } = req.body;
  if (!toUserId || !text) {
    return res.status(400).json({ error: 'Qabul qiluvchi va matn kerak' });
  }
  if (toUserId === req.userId) {
    return res.status(400).json({ error: 'O\'zingizga xabar yubora olmaysiz' });
  }
  const toUser = db.query('users').find(u => u.id === toUserId);
  if (!toUser) {
    return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
  }

  const message = db.query('messages').insert({
    fromUserId: req.userId,
    toUserId,
    text,
    productId: productId || null,
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({ message });
});

module.exports = router;
