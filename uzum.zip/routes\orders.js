const express = require('express');
const db = require('../database');
const { authMiddleware, optionalAuth } = require('../middleware/auth');
const TelegramBot = require('node-telegram-bot-api');
const router = express.Router();

function sendTelegramMessage(message) {
  const token = process.env.BOT_TOKEN;
  const chatId = process.env.ADMIN_CHAT_ID;
  if (!token || token === 'your_telegram_bot_token_here' || !chatId || chatId === 'your_chat_id_here') {
    console.log('Telegram bot not configured. Message:', message);
    return;
  }
  try {
    const bot = new TelegramBot(token);
    bot.sendMessage(chatId, message, { parse_mode: 'HTML' }).catch(err => {
      console.error('Telegram send error:', err.message);
    });
  } catch (err) {
    console.error('Telegram bot error:', err.message);
  }
}

router.post('/', optionalAuth, (req, res) => {
  const { name, phone, address, items } = req.body;
  if (!name || !phone) {
    return res.status(400).json({ error: 'Ism va telefon kerak' });
  }
  if (!items || items.length === 0) {
    return res.status(400).json({ error: 'Mahsulotlar kerak' });
  }

  const totalPrice = items.reduce((sum, item) => sum + (item.price || 0) * (item.quantity || 1), 0);

  const order = db.query('orders').insert({
    userId: req.userId || null, name, phone, address: address || '',
    items, totalPrice, status: 'pending',
    createdAt: new Date().toISOString()
  });

  let itemsHtml = items.map((item, i) =>
    `${i + 1}. ${item.name} x ${item.quantity || 1} = ${(item.price * (item.quantity || 1)).toLocaleString()} so'm`
  ).join('\n');

  const msg = `
🆕 <b>Yangi buyurtma!</b>

👤 <b>Ism:</b> ${name}
📞 <b>Telefon:</b> ${phone}
📍 <b>Manzil:</b> ${address || 'Kiritilmagan'}

📦 <b>Mahsulotlar:</b>
${itemsHtml}

💰 <b>Jami:</b> ${totalPrice.toLocaleString()} so'm
🕐 <b>Vaqt:</b> ${new Date().toLocaleString('uz-UZ')}
  `;

  sendTelegramMessage(msg);

  if (req.userId) {
    db.query('cartItems').deleteWhere(c => c.userId === req.userId);
  }

  res.json({ success: true, orderId: order.id });
});

router.get('/my', authMiddleware, (req, res) => {
  const orders = db.query('orders').filter(o => o.userId === req.userId);
  orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ orders });
});

module.exports = router;
