const express = require('express');
const db = require('../database');
const { authMiddleware, optionalAuth } = require('../middleware/auth');
const router = express.Router();

router.get('/', optionalAuth, (req, res) => {
  const { category, search } = req.query;
  let products = db.query('products').all();
  const users = db.query('users').all();

  if (category && category !== 'Hammasi') {
    products = products.filter(p => p.category === category);
  }
  if (search) {
    const q = search.toLowerCase();
    products = products.filter(p => p.name.toLowerCase().includes(q));
  }

  products.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const enriched = products.map(p => {
    const seller = users.find(u => u.id === p.userId);
    return {
      ...p,
      sellerName: seller ? seller.name : '',
      sellerAvatar: seller ? seller.avatar : null,
      sellerPhone: seller ? seller.phone : '',
      liked: false
    };
  });

  if (req.userId) {
    const likedIds = db.query('likes').filter(l => l.userId === req.userId).map(l => l.productId);
    for (const p of enriched) {
      p.liked = likedIds.includes(p.id);
    }
  }

  res.json({ products: enriched });
});

router.get('/:id', optionalAuth, (req, res) => {
  const product = db.query('products').find(p => p.id === parseInt(req.params.id));
  if (!product) return res.status(404).json({ error: 'Mahsulot topilmadi' });
  const seller = db.query('users').find(u => u.id === product.userId);
  const result = {
    ...product,
    sellerName: seller ? seller.name : '',
    sellerAvatar: seller ? seller.avatar : null,
    sellerPhone: seller ? seller.phone : '',
    liked: false
  };
  if (req.userId) {
    result.liked = !!db.query('likes').find(l => l.userId === req.userId && l.productId === product.id);
  }
  res.json({ product: result });
});

router.post('/', authMiddleware, (req, res) => {
  if (req.userRole !== 'seller') {
    return res.status(403).json({ error: 'Faqat sotuvchilar mahsulot qo\'sha oladi' });
  }
  const { name, price, category, description, images } = req.body;
  if (!name || !price || !category || !images || images.length < 2) {
    return res.status(400).json({ error: 'Nomi, narxi, kategoriyasi va kamida 2 rasm kerak' });
  }
  const product = db.query('products').insert({
    userId: req.userId, name, price, category,
    description: description || '', images,
    createdAt: new Date().toISOString()
  });
  res.json({ product });
});

router.put('/:id', authMiddleware, (req, res) => {
  const id = parseInt(req.params.id);
  const product = db.query('products').find(p => p.id === id);
  if (!product) return res.status(404).json({ error: 'Mahsulot topilmadi' });
  if (product.userId !== req.userId) return res.status(403).json({ error: 'Bu sizning mahsulotingiz emas' });

  const { name, price, category, description, images } = req.body;
  const changes = {};
  if (name) changes.name = name;
  if (price) changes.price = price;
  if (category) changes.category = category;
  if (description !== undefined) changes.description = description;
  if (images) changes.images = images;

  const updated = db.query('products').update(id, changes);
  res.json({ product: updated });
});

router.delete('/:id', authMiddleware, (req, res) => {
  const id = parseInt(req.params.id);
  const product = db.query('products').find(p => p.id === id);
  if (!product) return res.status(404).json({ error: 'Mahsulot topilmadi' });
  if (product.userId !== req.userId) return res.status(403).json({ error: 'Bu sizning mahsulotingiz emas' });
  db.query('products').delete(id);
  db.query('cartItems').deleteWhere(c => c.productId === id);
  db.query('likes').deleteWhere(l => l.productId === id);
  res.json({ success: true });
});

router.get('/my/list', authMiddleware, (req, res) => {
  const products = db.query('products').filter(p => p.userId === req.userId);
  products.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ products });
});

module.exports = router;
