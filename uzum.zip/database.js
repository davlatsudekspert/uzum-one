const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, 'data.json');

function load() {
  if (!fs.existsSync(DB_PATH)) {
    const data = getDefaultData();
    save(data);
    return data;
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function save(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function getDefaultData() {
  const hash = bcrypt.hashSync('123456', 10);
  return {
    users: [
      { id: 1, name: 'Ali Seller', phone: '+998901234567', password: hash, role: 'seller', avatar: null, createdAt: new Date().toISOString() },
      { id: 2, name: 'Vali Buyer', phone: '+998907654321', password: hash, role: 'buyer', avatar: null, createdAt: new Date().toISOString() }
    ],
    products: [
      { id: 1, userId: 1, name: 'Samsung Galaxy S24', price: 8500000, category: 'Texnika', description: 'Yangilangan model, 256GB xotira', images: ['https://images.unsplash.com/photo-1610945265064-0e34e551a22f?w=400&q=80', 'https://images.unsplash.com/photo-1610945265064-0e34e551a22f?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 2, userId: 1, name: 'MacBook Pro M3', price: 18500000, category: 'Texnika', description: '8GB RAM, 512GB SSD, Space Grey', images: ['https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80', 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 3, userId: 1, name: 'Changyutkich', price: 890000, category: 'Maishiy', description: 'Elektr changyutkich, 2000W', images: ['https://images.unsplash.com/photo-1558317374-067fb5f30001?w=400&q=80', 'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 4, userId: 1, name: "Mikroto'lqinli pech", price: 650000, category: 'Maishiy', description: 'LG markasi, 25L', images: ['https://images.unsplash.com/photo-1574269909862-7e1d70bb8078?w=400&q=80', 'https://images.unsplash.com/photo-1574269909862-7e1d70bb8078?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 5, userId: 1, name: 'Sport kostyum', price: 250000, category: 'Kiyim', description: 'Adidas original, M-XXL', images: ['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&q=80', 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 6, userId: 1, name: 'Krasovkalar', price: 350000, category: 'Kiyim', description: 'Nike Air Max, 39-44', images: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80', 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 7, userId: 1, name: 'Olma 1 kg', price: 12000, category: 'Oziq-ovqat', description: 'Fermer olmasi, yangi terilgan', images: ['https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400&q=80', 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 8, userId: 1, name: 'Non', price: 5000, category: 'Oziq-ovqat', description: 'Oq non, 500g', images: ['https://images.unsplash.com/photo-1549931319-a545753458f3?w=400&q=80', 'https://images.unsplash.com/photo-1549931319-a545753458f3?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 9, userId: 1, name: 'Gantel 10kg', price: 120000, category: 'Sport', description: 'Temir gantel, 10kg', images: ['https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?w=400&q=80', 'https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 10, userId: 1, name: "Futbol to'pi", price: 80000, category: 'Sport', description: "Adidas UCL to'pi", images: ['https://images.unsplash.com/photo-1614632537423-0ce1e4c23c6b?w=400&q=80', 'https://images.unsplash.com/photo-1614632537423-0ce1e4c23c6b?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 11, userId: 1, name: 'iPhone 15 Pro', price: 12500000, category: 'Texnika', description: '256GB, Titanium', images: ['https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80', 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80'], createdAt: new Date().toISOString() },
      { id: 12, userId: 1, name: 'Sovutgich', price: 3200000, category: 'Maishiy', description: 'Ikki eshikli, 300L', images: ['https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=400&q=80', 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=400&q=80'], createdAt: new Date().toISOString() }
    ],
    cartItems: [],
    likes: [],
    orders: [],
    messages: [],
    nextId: { users: 3, products: 13, cartItems: 1, likes: 1, orders: 1, messages: 1 }
  };
}

const db = {
  load,
  save,
  query(table) {
    const data = load();
    return {
      all() { return data[table] || []; },
      find(predicate) { return (data[table] || []).find(predicate); },
      filter(predicate) { return (data[table] || []).filter(predicate); },
      insert(item) {
        const list = data[table];
        const id = data.nextId[table] || 1;
        item.id = id;
        data.nextId[table] = id + 1;
        list.push(item);
        save(data);
        return item;
      },
      update(id, changes) {
        const list = data[table];
        const idx = list.findIndex(x => x.id === id);
        if (idx === -1) return null;
        list[idx] = { ...list[idx], ...changes };
        save(data);
        return list[idx];
      },
      delete(id) {
        const list = data[table];
        const idx = list.findIndex(x => x.id === id);
        if (idx === -1) return false;
        list.splice(idx, 1);
        save(data);
        return true;
      },
      deleteWhere(predicate) {
        const list = data[table];
        const toRemove = list.filter(predicate);
        for (const item of toRemove) {
          const idx = list.indexOf(item);
          list.splice(idx, 1);
        }
        save(data);
        return toRemove.length;
      }
    };
  }
};

module.exports = db;
